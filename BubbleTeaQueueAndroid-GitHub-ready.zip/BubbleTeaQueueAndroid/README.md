
## Build the APK automatically with GitHub Actions

1. Create a GitHub repository and upload the CONTENTS of this project so that `app`, `.github`, `build.gradle.kts`, and `settings.gradle.kts` are at the repository root.
2. Use `main` as the default branch.
3. Open the repository's **Actions** tab.
4. Choose **Build Android APK**.
5. Click **Run workflow**.
6. When the workflow finishes, open the successful run.
7. Under **Artifacts**, download **BubbleTeaQueue-debug-apk**.
8. Unzip the downloaded artifact and copy `app-debug.apk` to the Android phone.
9. On the phone, permit installation from the browser/files app when Android prompts for permission, then install the APK.

The workflow also builds automatically after pushes to `main`. The generated GitHub artifact is retained for 30 days by this project configuration.

### Repository layout

```
.github/workflows/build-apk.yml
app/
build.gradle.kts
settings.gradle.kts
README.md
.gitignore
```

### Important
This workflow creates a **debug APK**, suitable for your internal event/testing phone. It does not publish to Google Play. For a formal production distribution, configure a release signing key and build a signed release APK or Android App Bundle.
